<?php $__env->startSection('content'); ?>
 <style>
    .fc .fc-daygrid-event {
  white-space: normal !important;
  height: auto !important;
  width: auto !important;
  overflow: visible !important;
  padding: 0 !important;
  border: none;
}

.fc-event-main {
  white-space: normal !important;
}

.fc-daygrid-day-frame {
  display: block;
}

.fc-daygrid-event-harness {
  height: auto !important;
}

.fc .fc-daygrid-day {
  min-height: 120px;
  vertical-align: top;
}

/* .fc-daygrid-day {
  min-width: 200px !important;
}

.fc .fc-col-header-cell {
  min-width: 200px !important;
}

#calendar {
  min-width: 1400px; 
} */

 </style>
<div class="conatiner-fluid content-inner mt-n5 py-0">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Appointment Calendar</h4>
                    </div>
                    <a class="btn btn-primary" href="<?php echo e(route('admin.appointment.index')); ?>">Appointment List</a>
                </div>
                <hr style="color: blue;">
                <div class="card-body">
                    <!-- Calendar -->
                  <div style="overflow-x: auto;">
                    <div id="calendar"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- FullCalendar CSS & JS -->
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>


<script>
  document.addEventListener('DOMContentLoaded', function () {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth',
      fixedWeekCount: false,
      contentHeight: 'auto',
      dayMaxEventRows: true,
      events: [
       <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $color = match(strtolower($appointment->status)) {
            'confirmed' => '#198754',
            'requested', 'pending confirmation' => '#ffc107',
            'treated' => 'green',
            'cancelled' => 'red',
            default => '#0dcaf0',
        };

        // Parse time range
        $times = explode('-', $appointment->time_slot);
        $startTime = isset($times[0]) ? \Carbon\Carbon::parse(trim($times[0]))->format('h:i A') : '';
        $endTime = isset($times[1]) ? \Carbon\Carbon::parse(trim($times[1]))->format('h:i A') : '';
        ?>

        {
        title: `<div class="fc-appointment-card text-white rounded p-2 mt-2" style="background-color: <?php echo e($color); ?>">
                    <?php echo e($startTime); ?> - <?php echo e($endTime); ?><br>
                    Status: <?php echo e($appointment->status); ?><br>
                    Patient: <?php echo e($appointment->patient->name); ?><br>
                    Phone: <?php echo e($appointment->patient->phone); ?><br>
                    Doctor: <?php echo e($appointment->doctor->name); ?><br>
                    Remarks: <?php echo e($appointment->description); ?>

                </div>`,
        start: '<?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('Y-m-d')); ?>',
        allDay: true,
        },
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      ],
      eventContent: function (arg) {
        return { html: arg.event.title };
      }
    });

    calendar.render();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management\resources\views/admin/appointments/calendar.blade.php ENDPATH**/ ?>