<?php $__env->startSection('content'); ?>
<style>
    .modal-xl {
  max-width: 50% !important;
  width: 50% !important;
}
</style>
<div class="conatiner-fluid content-inner mt-n5 py-0">
    
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between mb-2">
                    <div class="header-title">
                        <h4 class="card-title">Symptom List</h4>
                    </div>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSymptomModal">+ Add Symptom</button>
                </div>
        

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped" id="symptomTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($symptom->name); ?></td>
                <td><?php echo e($symptom->description); ?></td>
                <td>
                    <button class="btn btn-sm btn-info edit-btn" 
                        data-id="<?php echo e($symptom->id); ?>" 
                        data-name="<?php echo e($symptom->name); ?>" 
                        data-description="<?php echo e($symptom->description); ?>"
                        data-bs-toggle="modal" 
                        data-bs-target="#editSymptomModal">
                        ✏️
                    </button>
                    <form action="<?php echo e(route('symptoms.destroy', $symptom->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">🗑️</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
</div>
</div>


<div class="modal fade" id="addSymptomModal" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <form action="<?php echo e(route('symptoms.store')); ?>" method="POST" class="modal-content">
      <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h5 class="modal-title">Add Symptom</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>


<div class="modal fade" id="editSymptomModal" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <form method="POST" class="modal-content" id="editForm">
      <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
      <div class="modal-header">
        <h5 class="modal-title">Edit Symptom</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="edit-id">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" id="edit-name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" id="edit-description" class="form-control"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>

<script>
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', function () {
            const id = this.dataset.id;
            const name = this.dataset.name;
            const description = this.dataset.description;

            document.getElementById('edit-name').value = name;
            document.getElementById('edit-description').value = description;
            const form = document.getElementById('editForm');
            form.action = `/symptoms/${id}`;
        });
    });
</script>
<script>
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', function () {
            const id = this.dataset.id;
            const name = this.dataset.name;
            const description = this.dataset.description;
            // Set form action dynamically
            const form = document.getElementById('editForm');
            form.action = `/symptoms/${id}`;

            // Set field values
            document.getElementById('edit-name').value = name;
            document.getElementById('edit-description').value = description || '';
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management\resources\views/admin/symptoms/index.blade.php ENDPATH**/ ?>