@extends('admin.dashboard.layouts.app')

@section('content')
  <h1>Receptionist Dashboard</h1>
  <!-- Your patient table or content here -->
@endsection
