@extends('admin.dashboard.layouts.app')

@section('content')
  <h1>Laboratoriest Dashboard</h1>
  <!-- Your patient table or content here -->
@endsection
