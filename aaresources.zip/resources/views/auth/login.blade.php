<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hospital Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #e8edf5;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .login-box {
      background: #fff;
      border-radius: 15px;
      padding: 30px 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
    }
    .logo img {
      width: 80px;
      border-radius: 50%;
    }
    .logo h4 {
      margin-top: 10px;
      font-weight: bold;
    }
    .form-control:focus {
      box-shadow: none;
    }
  </style>
</head>
<body>
  @if (session('error'))
  <div class="alert alert-danger">
      {{ session('error') }}
  </div>
@endif
<!-- Logo (outside box) -->
<div class="logo d-flex align-items-center justify-content-center mb-4">
  <img src="{{ asset('images/2037187.png') }}" alt="Hospital Logo">
  <h4>Hospital</h4>
</div>

<!-- Login Box -->
<div class="login-box">
 

  <h6 class="text-center text-muted mb-4">
    <i class="bi bi-box-arrow-in-right"></i> Sign in to start your session
  </h6>
  <form action="{{ route('login.post')}}" method="post">
    @csrf
    <div class="mb-3 input-group">
      <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
      <input type="email" class="form-control" placeholder="Email" name="email" required>
    </div>
    <div class="mb-3 input-group">
      <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
      <input type="password" class="form-control" placeholder="Password" name="password" required>
    </div>
    <div class="d-grid mb-3">
      <button type="submit" class="btn btn-primary">
        <i class="bi bi-box-arrow-in-right"></i> Sign In
      </button>
    </div>
    <div class="text-center text-muted mb-2">or</div>
    <div class="text-center">
      <a href="#" class="text-decoration-none">
        <i class="bi bi-key"></i> Forgot Password?
      </a>
    </div>
  </form>
</div>

<!-- Bootstrap JS & Icons -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</body>
</html>
