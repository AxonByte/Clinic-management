<?php $__env->startSection('content'); ?>
<div class="conatiner-fluid content-inner mt-n5 py-0">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Patient Info</h4>
                    </div>
                    <a class="btn btn-primary"  href="<?php echo e(route('admin.patient.index')); ?>">List of Patient</a>
                </div>
        

    <div class="row mt-3">
        
        <div class="col-md-6">
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-2"><i class="fas fa-user"></i> Basic Information</h5>
                </div>
                <div class="card-body row">
                    <div class="col-md-4 text-center">
                       <img 
                        id="preview" 
                        src="<?php echo e($patient->photo ? asset('storage/' . $patient->photo) : asset('default-image.png')); ?>" 
                        alt="Profile Preview" 
                        class="border mb-2" 
                        width="150" 
                        height="150" 
                        style="object-fit: cover;border-radius:50%;margin-left:35px;">
                    </div>
                    <div class="col-md-8 text-start" style="margin-top:10px;margin-left:10px!important;">
                        <p><strong class="text-secondary">Patient ID:</strong> <?php echo e($patient->id); ?></p>
                        <p><strong class="text-secondary">Full Name:</strong> <?php echo e($patient->name); ?></p>
                        <p><strong class="text-secondary">Email Address:</strong> <?php echo e($patient->email); ?></p>
                        <p><strong class="text-secondary">Contact Number:</strong> <?php echo e($patient->phone); ?></p>
                        <p><strong class="text-secondary">National ID:</strong> <?php echo e($patient->detail->nationalid); ?></p>
                        <p><strong class="text-secondary">Residential Address:</strong> <?php echo e($patient->address); ?></p>
                        <p><strong class="text-secondary">National ID:</strong> <?php echo e($patient->detail->gender); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-2"><i class="fas fa-heartbeat"></i> Medical Information</h5>
                </div>
                <div class="card-body">
                    <p><strong class="text-secondary">Blood Group:</strong> <?php echo e(optional($patient->detail)->blood_group ?? 'N/A'); ?></p>
                    <p><strong class="text-secondary">Birth Date:</strong> <?php echo e(optional($patient->detail)->birth_date ?? 'N/A'); ?></p>
                    <p><strong class="text-secondary">Doctor:</strong> <?php echo e($patient_doctor ?? ''); ?></p>
                    <p><strong class="text-secondary">Height:</strong> <?php echo e(optional($patient->detail)->height ?? 'N/A'); ?></p>
                    <p><strong class="text-secondary">Weight:</strong> <?php echo e(optional($patient->detail)->weight ?? 'N/A'); ?></p>
                    <p><strong class="text-secondary">Known Allergies:</strong> <?php echo e(optional($patient->detail)->allergies ?? 'N/A'); ?></p>
                    <p><strong class="text-secondary">Medical History:</strong> <?php echo e(optional($patient->detail)->medical_history ?? 'N/A'); ?></p>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-2"><i class="fas fa-ambulance"></i> Emergency Contact</h5>
                </div>
                <div class="card-body">
                    <p><strong class="text-secondary">Emergency Contact Person:</strong> <?php echo e(optional($patient->detail)->emergency_contact_person ?? 'N/A'); ?></p>
                    <p><strong class="text-secondary">Emergency Contact Number:</strong> <?php echo e(optional($patient->detail)->emergency_contact ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management\resources\views/admin/patients/show.blade.php ENDPATH**/ ?>