<?php $__env->startSection('content'); ?>
    <div class="conatiner-fluid content-inner mt-n5 py-0">
        <div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div class="header-title">
                                <h4 class="card-title">Add Doctor</h4>
                            </div>
                        </div>
                        <div class="card-body">

                            <form action="<?php echo e(route('admin.doctor.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="name"
                                            class="form-label required text-secondary fw-bold">NAME</label>
                                        <input type="text" id="name" class="form-control" name="name" required>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="email"
                                            class="form-label required text-secondary fw-bold">EMAIL</label>
                                        <input type="email" id="email" class="form-control" name="email" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="password"
                                            class="form-label required text-secondary fw-bold">PASSWORD</label>
                                        <input type="password" id="password" class="form-control" name="password" required>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="address"
                                            class="form-label required text-secondary fw-bold">ADDRESS</label>
                                        <input type="text" id="address" class="form-control" name="address" required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="phone"
                                            class="form-label required text-secondary fw-bold">PHONE</label>
                                        <input type="number" id="phone" class="form-control" name="phone" required>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="department" class="form-label fw-bold text-secondary">DEPARTMENT</label>
                                        <select class="form-select" id="department" name="department" required>
                                            <option value="">Select Department</option>
                                            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="description" class="form-label fw-bold text-secondary">DOCTOR
                                        DESCRIPTION</label>
                                    <textarea id="doctorDesc" class="form-control" name="description"></textarea>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="signature" class="form-label fw-bold text-secondary">SIGNATURE <span
                                                class="text-danger">*</span></label>
                                        <input type="file" class="form-control" id="signature" name="signature" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="photo" class="form-label fw-bold text-secondary">IMAGE</label>
                                        <input type="file" class="form-control" id="photo" name="photo">
                                    </div>
                                </div>

                        </div>
                        <div class="row mb-5">
                          <div class="text-end" style="margin-right: 10px;">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="submit" class="btn btn-danger">cancel</button>
                        </div>
                        </div>
                    </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
     <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script>
    let departmentEditor;
    ClassicEditor
        .create(document.querySelector('#doctorDesc'))
        .then(editor => {
            departmentEditor = editor;
            editor.ui.view.editable.element.style.height = '300px';
        })
        .catch(error => {
            console.error('CKEditor initialization error:', error);
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management\resources\views/admin/doctors/create.blade.php ENDPATH**/ ?>