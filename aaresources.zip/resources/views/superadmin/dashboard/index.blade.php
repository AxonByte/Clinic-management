@extends('admin.dashboard.layouts.app')

@section('content')
  <h1>Super Admin Dashboard</h1>
  <!-- Your patient table or content here -->
@endsection
