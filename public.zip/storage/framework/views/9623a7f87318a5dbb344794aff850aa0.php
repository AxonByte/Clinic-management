

<?php $__env->startSection('content'); ?>
  <h1>Super Admin Dashboard</h1>
  <!-- Your patient table or content here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.dashboard.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Hospital-Management\resources\views/superadmin/dashboard/index.blade.php ENDPATH**/ ?>